import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;

public class GUI extends JFrame implements ActionListener{
	private ArrayList<JButton> botones;
	private JPanel panel1, panel2;
	private JLabel text;
	private JTextField CajaTexto;
	private ActionListener action;
	
	public GUI() {
		super("ejemplo de interfaz");
		accion();
		CrearBotones();
		//CrearText();
		setSize(400, 300);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	
	public void accion() {
		action = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String opcion = (String)e.getActionCommand();
				if (opcion.equals("Boton 1")) {
					botones.get(0).setText("Oprimio el boton");
				}if (opcion.equals("Boton 2")) {
					botones.get(1).setText("Oprimio el boton");
				}
			}
		};
	}
public void CrearBotones() {
	setLayout(new BorderLayout());
	panel1 = new JPanel();
	panel1.setLayout(new GridLayout(5, 5));
	botones = new ArrayList<JButton>();
	for(int i=0; i<10; i++) {
		botones.add(i, new JButton("Boton "+(i+1)));
		panel1.add(botones.get(i));
		if (i<5) {
			botones.get(i).addActionListener(action);
		}else {
			botones.get(i).addActionListener(this);
		}
	}
	add(panel1);
}


@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}
}
