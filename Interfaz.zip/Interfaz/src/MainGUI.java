
public class MainGUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI panel = new GUI();

	}

}
